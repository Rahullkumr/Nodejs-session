var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
const connection=require('../connection/mysql.connection');

/* GET users listing. */
router.get('/all', (req, res)=> {
  connection.query('SELECT * FROM users',(err,result)=>{
    if(err) {
      res.send({error:true,message:err.message});
    }else {
      res.send({error:false,data:result});
    }
  })
  
});



router.post('/create', (req, res)=> {
  const user=req.body;
  console.log(user)
  const salt = bcrypt.genSaltSync(10);
const hash = bcrypt.hashSync(user.Password, salt);
  connection.query(`INSERT INTO users(id, Name, Email, Password,
     isActive) VALUES 
  (0,'${user.Name}','${user.Email}','${hash}',0)`,
  (err,result)=>{
    if(err) {
      res.send({error:true,message:err.message});
    }else {
      res.send({error:false,data:result});
    }
  })
})

router.post('/find/:id', (req, res)=> {
  const id=req.params.id;
  connection.query(`selecrt * from users where id=${id}`,(err,result)=>{
    if(err) {
      res.send({error:true,message:err.message});
    }else {
      res.send({error:false,data:result});
    }
  })
})

router.post('/update/:id', (req, res)=> {
  const id=req.params.id;
  connection.query(`update users set Name='${req.body.Name}' where id=${id}`,(err,result)=>{
    if(err) {
      res.send({error:true,message:err.message});
    }else {
      res.send({error:false,data:result});
    }
  })
})


router.post('/delete/:id', (req, res)=> {
  const id=req.params.id;
  connection.query(`update users set isActive=1 where id=${id}`,(err,result)=>{
    if(err) {
      res.send({error:true,message:err.message});
    }else {
      res.send({error:false,data:result});
    }
  })
})
module.exports = router;
